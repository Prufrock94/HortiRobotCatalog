# Horti Robot Catalog

Interactieve catalogus met filtering, detailpaneel, issue-knoppen en JSON-data.
